function longestWorld(str1, str2) {
    let worlds = []
    let compareWorld = str1

    // for(let i = 0; i < arr.length; i++) {
    //     for(j = 0; j < arr.length; j++) {
            
    //     }
    // }

    // return worlds

    for(const i of str1) {
        return i
    }

    // return worlds
}

console.log(longestWorld("salom", "tamom"));